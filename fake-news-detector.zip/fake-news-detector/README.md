# Fake News Detector

A Streamlit app that estimates whether a news headline is REAL or FAKE
using a TF-IDF + Logistic Regression model trained on the bundled demo
dataset (`data/real_news.csv`, `data/fake_news.csv`).

> The bundled dataset is a small demo corpus (~2,400 headlines). Treat
> predictions as illustrative, not authoritative — swap in a larger
> labeled dataset (LIAR, FakeNewsNet, Kaggle Fake-and-Real-News) for
> production use.

## Run locally

```bash
pip install -r requirements.txt
python train_model.py   # trains model, writes model/fake_news_model.joblib
streamlit run app.py
```

## Deploy (free) — Streamlit Community Cloud

1. Push this folder to a public (or private) GitHub repo.
2. Make sure `model/fake_news_model.joblib` and `model/signal_words.json`
   are committed (or add a build-time training step — see note below).
3. Go to https://share.streamlit.io, sign in with GitHub, and in your
   workspace click **"Create app"** → **"Yup, I have an app"** → fill in
   repo / branch / main file path (`app.py`) → pick a subdomain
   (optional) → **Deploy**.
4. Streamlit Cloud installs `requirements.txt` automatically and gives
   you a public `https://<your-subdomain>.streamlit.app` URL within a
   few minutes.

**Note on the model file:** `.joblib` files are binary; commit it as-is
with `git add -f model/fake_news_model.joblib` if your `.gitignore`
excludes it. Alternatively, have the app train on first boot by calling
`train_model.main()` from `app.py` if the model file is missing.

## Deploy (free) — Hugging Face Spaces

1. Create a new Space → SDK: Streamlit.
2. Upload/push the same files (`app.py`, `requirements.txt`, `data/`,
   `train_model.py`).
3. Add a `packages.txt` only if you need system packages (not needed here).
4. Space builds automatically and serves at
   `https://huggingface.co/spaces/<user>/<space-name>`.

## Deploy — Render / Railway / Fly.io (more control, still free tier)

Add a `Procfile` or start command:
```
streamlit run app.py --server.port $PORT --server.address 0.0.0.0
```
